(TeX-add-style-hook
 "istprog"
 (lambda ()
   (TeX-run-style-hooks
    "lastpage"
    "fancyhdr"
    "stringstrings"
    "ifthen"
    "amssymb"
    "longtable")
   (TeX-add-symbols
    '("intacronym" 2)
    '("inttabref" 1)
    '("intfigref" 1)
    '("ithl" 1)
    '("intacthl" 1)
    '("istTestDisseminationLevel" 1)
    '("istChange" 4)
    "maketoc"
    "GetDeliverableID"
    "istpis"
    "istdis"
    "istmakechangelog"
    "writechlog"
    "noexpand"
    "shadeofgray"
    "ProjectRefNo"
    "ProjectFP"
    "ProjectAcronym"
    "ProjectFullTitle"
    "ProjectInstrument"
    "ProjectStartDuration"
    "Security"
    "ContractualDate"
    "ActualDate"
    "delivNumber"
    "delivName"
    "delivShortTile"
    "delivType"
    "delivStatus"
    "temparg"
    "delivVersion"
    "NumberOfPages"
    "delivMonth"
    "delivYear"
    "delivDissLevel"
    "delivWP"
    "delivTask"
    "delivTaskTitle"
    "delivTaskDuration"
    "delivResponsible"
    "delivOtherContributors"
    "delivInstContributors"
    "delivAuthor"
    "delivReviewer"
    "delivFPAuthor"
    "delivProjectOfficer"
    "delivKeywords"
    "delivAbstract"
    "delivExecSummary"
    "delivDisclaimer"
    "arraystretch"
    "partners"
    "webAddress"
    "principalContact"
    "logo")
   (LaTeX-add-environments
    "intacronyms"))
 :latex)

